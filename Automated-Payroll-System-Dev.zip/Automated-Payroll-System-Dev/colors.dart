import 'package:flutter/material.dart';

class AppColors {
  // static const Color primary = Color(0xC3019C35);
  static const Color primary = Color(0xFF000061);
  static const Color error = Color(0xFFFF0000);
  static const Color success = Color(0xFF00FF00);
  static const Color warning = Color(0xFFF5BD00);
  static const Color subtle = Color(0xFF878794);
  // static const Color primary_light = Color(0xFF99D3A6);
  static const Color primary_light = Color(0xFFDEDEF6);
  static const Color white = Color(0xFFFFFFFF);
  static const Color error_light = Color(0xFFF88787);
  static const Color primary_medium = Color(0xFF000096);

  // Private constructor to prevent instantiation
  AppColors._();
}
