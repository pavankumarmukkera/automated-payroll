import 'package:flutter/material.dart';

class LaunchAnimation extends StatefulWidget {
  const LaunchAnimation({super.key});

  @override
  State<LaunchAnimation> createState() => _LaunchAnimationState();
}

class _LaunchAnimationState extends State<LaunchAnimation> {
  @override
  Widget build(BuildContext context) {
    return const Scaffold();
  }
}
