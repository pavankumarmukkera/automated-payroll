class ApiUrls {
  static const String primary = 'https://gdpest.in/techlance_project_aps/';
  // Private constructor to prevent instantiation
  ApiUrls._();
}
